def calculo (x):
  x1 = (x*46)/100
  x2 = (x*32)/100
  x3 = (x*22/100)
  
  return (x1, x2, x3)
def convencao (x):
  c = x
  F = c * (9.0/5.0) + 32
  
  return (F)

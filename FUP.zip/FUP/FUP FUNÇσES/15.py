def separar_digitos(numero):
    if not (1000 <= numero <= 9999):
        return "Número inválido"
    lista = []
    while numero > 0:
        digito = numero % 10
        lista.append(digito)
        numero = numero // 10
    lista.reverse()
    milhar = lista[0]
    centena = lista[1]
    dezena = lista[2]
    unidade = lista[3]
    return milhar, centena, dezena, unidade

def ant_e_suce (x):
  y1 = x - 1
  y2 = x + 1
  
  return (y1, y2)
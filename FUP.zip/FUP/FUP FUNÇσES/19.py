def contador (x):
  cem = x//100
  x = x - (cem*100)
  
  cinq = x//50
  x = x - (cinq*50)
  
  vinte = x//20
  x = x - (vinte*20)
  
  dez = x//10
  x = x - (dez*10)
  
  cinco = x//5
  x = x - (cinco*5)
  
  dois = x//2
  x = x - (dois*2)
  
  um = x
  
  return (cem, cinq, vinte, dez, cinco, dois, um)
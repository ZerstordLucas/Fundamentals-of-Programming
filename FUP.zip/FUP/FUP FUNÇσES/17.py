import math
def calculo (x, y):
  z = (x**2 + y**2)
  z = round(math.sqrt(z),2)
  return (z)

def convert(segundos):
    segundos = segundos % (24*3600)
    horas = segundos // 3600
    segundos %= 3600
    minutos = segundos // 60
    segundos %= 60
    
    return int(horas),int(minutos),int(segundos)

def calculo (a1, a2, a3, vg):
  vi = a1 + a2 + a3
  
  p1 = (a1/vi)*100
  p2 = (a2/vi)*100
  p3 = (a3/vi)*100
  
  p10 = round((p1*vg)/100)
  p20 = round((p2*vg)/100)
  p30 = round((p3*vg)/100)
  
  return (p10, p20, p30)
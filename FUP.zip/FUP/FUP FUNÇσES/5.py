def a_quad (x):
  l = x**2
  
  return (l)

def calculo (x):
  p = float(21.37)
  pc = (x*p)/100
  x = x + pc
  
  return (x)
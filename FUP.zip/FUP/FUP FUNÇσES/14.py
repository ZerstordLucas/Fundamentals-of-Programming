def inverter_numero(n):
  if n < 100 or n > 999:
    return "Número inválido"
  lista = []
  while n > 0:
    digito = n % 10
    lista.append(digito)
    n = n // 10
  inverso = 0
  for i in range(len(lista)):
    digito = lista[i]
    potencia = 10 ** (len(lista) - i - 1) #esta parte
    inverso = inverso + digito * potencia
  return inverso

#Precisei do chat gpt para ajudar formar o códico para unir a lista invertida
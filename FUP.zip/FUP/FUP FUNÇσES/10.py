import math
def calculo (g):
  r = g
  π = 3.14
  
  rad = math.radians(r)
  return (rad)
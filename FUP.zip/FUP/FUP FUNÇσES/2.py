def funcao (x):
  real = float(x)
  dollar = float(5.27)
  conve = real*dollar
  return(conve)

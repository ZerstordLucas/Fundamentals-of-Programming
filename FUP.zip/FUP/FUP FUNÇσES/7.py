def calculo (x):
  x **= x
  
  return (x)
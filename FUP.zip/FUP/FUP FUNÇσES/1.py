def dobra_e_passa_p_proximo (y):
  y = y*2
  
  return (y)

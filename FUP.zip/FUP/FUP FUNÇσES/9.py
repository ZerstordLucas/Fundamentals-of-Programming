def calculo (x):
  k = x
  m = k/3.6
  return (m)

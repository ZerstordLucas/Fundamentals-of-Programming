def calculos (r):
  π = float(3.14)
  f = float(1.33)
  
  v = round(f*π*r**3,2)
  a = round(4*π*r**2,2)
  
  return (v, a)
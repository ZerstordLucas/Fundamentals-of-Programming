def calculos (x, y, z):
  p1 = x**2 + y**x + z**2
  p2 = (x+y+z)**2
  
  return (p1, p2)
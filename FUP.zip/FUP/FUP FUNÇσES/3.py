def calculo (x1, x2):
  h = x1
  b = x2
  y1 = h*b
  y2 = 2*(b+h)
  return (y1, y2)

pergunta = "S"
while pergunta =="S":
    
    matriz = []
    for linha in range(4):
        l = []
        matriz.append(l)
        for coluna in range(4):
            l.append(int(input(f"Digite um número para preencher a linha {linha+1}, coluna {coluna+1} da matriz: ")))

    print("A matriz gerada foi:")  
    contador = 0
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            if matriz[i][j] > 10:
                contador += 1
                print(f"{matriz[i][j]}\t",end = "")
            else:
                print(f"{matriz[i][j]}\t", end = "")
        print()
    
    print(f"A qntd de números que são maiores que 10 na matriz é {contador}")
    
    pergunta = input("Gostaria de lontinuar? [S/N]\n").upper()
print("Finalizando programa...")
def apresentar_matriz(x):
    for linha in range(len(x)):
        for coluna in range(len(x)):
            print(f"{x[linha][coluna]}\t", end = "")
        print()

def matriz_maiores(x, y):
    matriz_maior_valores = []
    
    for linha in range(len(x)):
        l = []
        matriz_maior_valores.append(l)
        for coluna in range(len(x[0])):
            l.append(max(x[linha][coluna], y[linha][coluna]))
    
    return matriz_maior_valores

pergunta = "S"
while pergunta =="S":
    matriz = []
    matriz_1 = []
    
    for linha in range(4):
        l =[]
        matriz.append(l)
        for coluna in range(4):
            l.append(int(input(f"Digite um número para a matriz 1, linha {linha+1}, coluna {coluna+1}:\n")))

    for linha1 in range(4):
        l1 = []
        matriz_1.append(l1)
        for coluna1 in range(4):
            l1.append(int(input(f"Digite um número para a matriz 2, linha {linha1+1}, coluna {coluna1+1}:\n")))
    
    matriz_maior_valores = matriz_maiores(matriz, matriz_1)
    
    print("/"*40, end = "")
    print("\nA matriz 1: ")
    apresentar_matriz(matriz)
    
    print("/"*40, end = "")
    print("\nA matriz 2:")
    apresentar_matriz(matriz_1)
    
    print("/"*60, end = "")
    print("\nA matriz dos maiores números: ")
    apresentar_matriz(matriz_maior_valores)

    pergunta = input("Gostaria de continuar? [S/N]\n").upper()
print("Finalizando o programa...")
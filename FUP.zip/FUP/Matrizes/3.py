def gerador_matriz(x):
    matriz = []
    for linha in range(x):
        l = []
        matriz.append(l)
        for coluna in range(x):
            l.append( (linha+1) * (coluna+1))

    return matriz

pergunta = "S"
while pergunta == "S":

    num = int(input("Digite um número para gerar a matriz: "))    
    if num < 1:
        print("Não há matriz para esse valor")
        continue
    elif num == 1:
        print("Não é uma matriz, e sim um vetor!")
        print(1)
        continue

    matriz_final = gerador_matriz(num)
    print("Matriz gerada")
    for l in range(len(matriz_final)):
        for c in range(len(matriz_final)):
            print(f"{matriz_final[l][c]}\t" , end= "")
        print()

    pergunta = input("Gostaria de continuar? [S/N]\n").upper()
print("Finalizando programa...")

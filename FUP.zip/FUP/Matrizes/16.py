def apresentar_matriz (x):
    for l in range(len(x)):
        for c in range(len(x)):
            print(f"{x[l][c]}\t", end = "")
        print()

pergunta = "S"
while pergunta == "S":
    matriz = []
    for linha in range(12):
        linha_guarda = []
        matriz.append(linha_guarda)
        for coluna in range(13):
            linha_guarda.append(int(input(f"Digite um valor para a linha {linha +1}, coluna {coluna+1}:  ")))
    
    matriz_resultado = []
    for l in range(len(matriz)):
        valor_max = max(matriz[l])
        divido = []
        matriz_resultado.append(divido)
        for c in range(len(matriz)):
            divido.append(round(matriz[l][c] /valor_max ,2))

    print("=" * 30)
    print("A matriz gerada pelo usuário:")
    apresentar_matriz(matriz)

    print("=" * 30)
    print("O resultado:")
    apresentar_matriz(matriz_resultado)

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando programa...")
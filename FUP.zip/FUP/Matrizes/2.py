def gerador_matriz (x):
    matriz_gerada = []
    for linha in range(x):
        l = []
        matriz_gerada.append(l)
        for coluna in range(x):
            l.append(0)

    return matriz_gerada

def diagonal_matriz (l):
    matriz_final = gerador_matriz(l)
    contador = 0
    while contador != l:
        matriz_final[contador][contador] = 1
        contador += 1

    return matriz_final

pergunta = "S"
while pergunta =="S":
    num = int(input("Digite um número inteiro positivo para gerar uma matriz: "))
    if num < 1:
        print("Não há matriz para esse valor")
        continue
    elif num == 1:
        print("Não é uma matriz, e sim um vetor!")
        print(1)
        continue

    print("A matriz gerada é: ")

    matriz_f = diagonal_matriz(num)
    for linha in range (len(matriz_f)):
        for coluna in range (len(matriz_f[linha])):
            print(f"{matriz_f[linha][coluna]}\t",end = "")
        print()
            
    pergunta = input("Gostaria de tentar novamente? [S/N] ").upper()
print("Finalizando programa...")
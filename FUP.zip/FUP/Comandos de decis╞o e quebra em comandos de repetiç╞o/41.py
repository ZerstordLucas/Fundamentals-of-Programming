pergunta = "S"
while pergunta == "S":
    x = int(input("Digite um número: "))
    xtexto = str(x)
    y = " "
    for i in xtexto:
        if i == "0":
            y +="1"
        else:
            y+=i
    print(y)
        



    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

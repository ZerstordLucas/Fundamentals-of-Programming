resposta = "S"
while resposta == "S":
    x1 = int(input("Digite o primeiro número: "))
    x2 = int(input("Digite o segundo número: "))
    if x1 > x2:
        print(x1)

    elif x1 < x2 :
        print(x2)

    else:
        print("Os números são iguais!")
    resposta = input("Quer continuar? [S/N]").upper()
print("Fim do progama!")

    


resposta = "S"
while resposta == "S":
    x1 = int(input("Digite um número: "))
    x2 = int(input("Digite um número: "))
    x3 = int(input("Digite um número: "))

    if x1 > x2 and x1 > x3:
        print(f"O maior valor é {x1}")
    elif x2 > x1 and x2 > x3:
        print(f"O maior valor é {x2}")
    else:
        print(f"O maior valor é {x3}")
    resultado = input("Gostaria de continuar testando? [S/N]").upper()
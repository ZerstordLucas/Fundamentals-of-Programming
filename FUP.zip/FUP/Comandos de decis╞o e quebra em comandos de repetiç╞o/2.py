resposta = "S"
while resposta == "S":
    x = int(input("Digite um número: "))
    if x % 2 :
        print("O número é impar! ")
    else:
        print("O npumero é par! ")
    resposta = input("Quer continuar? [S/N]").upper()
print("Como dizia minha ex, terminamos.")

#. Faça um algoritmo que seja capaz de obter o quociente inteiro da divisão de dois números 
#fornecidos, sem utilizar a operação de divisão (/), nem a operação de divisão inteira (//) e 
#nem a operação de resto da divisão inteira (%)

def cal(Dendo, Disor):
    q =0
    while Dendo >= Disor:
        Dendo -= Disor
        q += 1
    return(q)


pergunta = "S"
while pergunta == "S":
    x1 = int(input("Digite o dividendo: "))
    x2 = int(input("Digite o divisor: "))
    
    if x1 >= x2:
        print(cal(x1,x2))
    else:
        print(cal(x2,x1))

    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()
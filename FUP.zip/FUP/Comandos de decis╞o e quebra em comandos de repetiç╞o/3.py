resposta = "S"
while resposta == "S":
    s= 0
    for i in range(4):
        x = int(input("Digite um número: "))
        if x % 2 == 0 :
            s+=x
        else:
            s+=0
    print(s)
    print("Fim")
    resposta = input("Quer continuar? [S/N]").upper()

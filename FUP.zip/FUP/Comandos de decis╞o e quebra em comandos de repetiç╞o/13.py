def delt(a,b,c):
    delta = (b**2)-4*a*c
    
    if delta > 0:
        x1 = (-b + (delta**0.5)) / (2*a)
        x2 = (-b - (delta**0.5)) / (2*a)
        return(x1,x2)
    elif delta == 0:
        x = -b/ (2*a)
        return(x,None)
    elif delta < 0 :
        return None, None

pergunta = "S"
while pergunta == "S":
    a = float(input("Digite um valor para a: "))
    if a == 0: 
        print("A tem que ser diferente de 0")
    b = float(input("Digite um valor para b: "))
    c= float(input("Digite um valor para c: "))
    
    x1, x2 = delt(a,b,c)

    if x1 == None:
        print("Não existem raízes reais")
    elif x2 == None:
        print("AS duas raízes são iguais")
        print(f"x1 = {x1:.6f}")
    else:
        print("As duas raizes são reais")
        print(f"x1 = {x1:.6f}")
        print(f"x2 = {x2:.6f}")

    print("Fim de cálculo!")
    pergunta = str(input("Quer um novo cálculo? [S/N]").upper())

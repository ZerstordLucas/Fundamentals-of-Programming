def priminho(y):
    pri = []
    d =2
    while y > 1:
        while y % d == 0:
            pri.append(d)
            y /= d
        d += 1
    return(pri)


pergunta = "S"
while pergunta == "S":
    x = int(input("Digite um número: "))
    
    primos = priminho(x)
    maior = max(primos)
    print(f"O maior número primo de {x} é {maior}")
    pergunta = input("Quer continuar? [S/N]").upper()

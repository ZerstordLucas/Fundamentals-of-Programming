x = []
for i in range(1000, 2000):
    if i % 11 == 5:
        x.append(i)
print(x)
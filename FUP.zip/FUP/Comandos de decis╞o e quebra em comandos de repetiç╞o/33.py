pergunta = "S"
while pergunta == "S":
    x = int(input("Digite um número: "))
    l= []
    for i in range(1, x):
        if x % i == 0:
            l.append(i)
            
    s = sum(l)
    if s == x:
        print(f"{x} é perfeito! Pois a soma dos números {l} é igual a {x}")
    else:
        print(f"{x} não é perfeito! Pois a soma dos números {l}  não é igual a {x}. Paia.")
    print("Fim")
    pergunta = input("Quer continuar? [S/N]").upper()


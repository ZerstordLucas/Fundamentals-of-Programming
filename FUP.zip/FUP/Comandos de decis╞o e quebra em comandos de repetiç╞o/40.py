pergunta = "S"
while pergunta == "S":
    x = int(input("Digite um número: "))
    xtexto = str(x)
    contador = 0
    for i in xtexto:
        if i == "1":
            contador +=1
    print(contador)



    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

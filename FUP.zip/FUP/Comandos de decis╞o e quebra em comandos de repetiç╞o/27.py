pergunta = "S"
while pergunta == "S":
    l = []

    parada = "S"
    while parada == "S":
        x = int(input("Digite um número: "))
        l.append(x)
        parada = input("Mais algum número? [S/N]  ").upper()
    
    max = max(l)
    min = min(l)

    print(f"O maior número é {max} e o menor número é {min}")
    
    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

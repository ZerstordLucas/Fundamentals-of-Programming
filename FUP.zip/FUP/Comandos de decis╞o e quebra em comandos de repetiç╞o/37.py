from fractions import Fraction
def mdc(x1,x2):
    while x2 != 0:
        resto = x1 % x2
        x1 = x2
        x2 = resto
    return(x1)

def simplif(x1,x2):
    comun = mdc(x1, x2)
    r0 = x1// comun
    r1 = x2 // comun
    return(Fraction(r0, r1))

pergunta = "S"
while pergunta == "S":
    num = int(input("Digite numerador: "))
    den = int(input("Digite denominador: "))

    fracao = simplif(num,den)
    print(f"O resultado é a fração simplificada {fracao}")
    print("Fim")
    pergunta = input("Quer continuar? [S/N]").upper()



x = 1
while x <= 100:
    print(x)
    x +=1 
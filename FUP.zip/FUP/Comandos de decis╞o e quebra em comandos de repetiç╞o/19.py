pergunta = "S"
while pergunta == "S":
    x = int(input("Digite um número:  "))

    if x == 0:
        print(0)
       
    elif x > 0 :
        print(1)
    elif x < 0:
        print(-1)

    print("Fim do teste")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

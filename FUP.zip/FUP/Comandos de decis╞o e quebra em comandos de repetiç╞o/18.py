pergunta = "S"
while pergunta == "S":
    x = (input("Digite uma data no formato DD/MM/AAAA:  "))
    
    info = x.split("/")
    dia = int(info[0])
    mes = int(info[1])
    ano = int(info[2])
    
    if 1 < dia > 31 or 1 < mes > 12 or ano < 0:
        print("Data inválida")
        continue
    
    meses = ["Janeiro","Fevedeiro", "Março", "Abril", "Maio", "Junho", "Julho",
             "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
    
    print(f"{dia} de {meses[mes-1]} de {ano}")

    
    print("Fim")
    pergunta = input("Gostaria de continuar? [S/N] ").upper
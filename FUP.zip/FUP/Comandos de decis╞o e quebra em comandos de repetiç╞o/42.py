pergunta = "S"
while pergunta == "S":
    x = input("Digite um número: ")
    xtexto = x
    y = 0
    for i in xtexto:
        if i == " ":
            y +=1
    print(y)
        



    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

pergunta = "S"
while pergunta == "S":
    operação = input("Qual operação? [1,2,3,4], e digite [5] para sair: ")
    if operação =="5":
        break
    num1 = int(input("Digite o primeiro número: "))
    num2 = int(input("Digite o segundo número: "))

    if operação == "1":
        print(num1 + num2)
    elif operação == "2":
        print(num1 - num2)
    elif operação == "3":
        print(num1 * num2)
    elif operação == "4":
        print(num1 / num2)
    print("Fim do calculo!")
    pergunta = input("Quer aprender mais? [S/N]").upper()

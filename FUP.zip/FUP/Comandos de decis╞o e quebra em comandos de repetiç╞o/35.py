def separador(x):
    um = x//100
    dois = x % 100
    return(um, dois)

pergunta = "S"
while pergunta == "S":
    numero = int(input("Digite um número de 4 algarismos:  "))

    soma = sum(separador(numero))
    if soma**2 == numero:
        print(f"Propiedade verdadeira! a soma de{separador(numero)} ao quadrado é igual a {numero}")
    else:
        print(f"Propiedade é falsa! a soma de{separador(numero)} ao quadrado  não é igual a {numero}")
  
    print("Fim")
    pergunta = input("Quer continuar? [S/N]").upper()



resultado = "S"
while resultado == "S":
    x = int(input("Digite um número: "))
    if x >= 0:
        x = x**0.5
        print(x)
    else:
        print("Raiz irreal")
    print("Fim")
    resultado = input("Gostaria de continuar? [S/N]").upper()

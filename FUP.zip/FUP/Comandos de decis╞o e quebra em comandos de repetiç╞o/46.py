def testador (x):
    y = x[::-1]
    if y == x:
        return(True)
    else:
        return(False)
    
pergunta = "S"
while pergunta == "S":
    texto = input("Digite seu texto meu nobre:  ")

    palíndromo = testador(texto)
    if palíndromo == True:
        print("É um palíndromo! Irrul!")
    elif palíndromo == False:
        print("Paia demais. Nem é um palíndromo")

    pergunta = input("Gostaria de testar outro texto? [S/N] ").upper()
    
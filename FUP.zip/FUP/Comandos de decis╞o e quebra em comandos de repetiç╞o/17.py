pergunta = "S"
while pergunta == "S":
    x = int(input("Digite um número: "))
    if x > 0:
        print(f"Número {x} ao quadrado: {x**2}")
        print(f"Número {x} ao cubo : {x**3}")
        print(f"Raiz quadrada de {x}: {x**0.5}")
    else:
        print("Fim do progama")
        break
    print("Fim da resposta")
    pergunta = input("Gostaria de continuar? [S/N]  ").upper()
pergunta = "S"
while pergunta == "S":
    x1 = float(input("Digite o primeiro número: "))
    x2 = float(input("Digite o segundo número: "))
    escolha = int(input("Escolha de 1 a 4: "))

    if escolha == 1:
        print((x1+x2)/2)
    
    elif escolha == 2:
        if x1 > x2:
            print(x1 - x2)
        else:
            print(x2-x1)
    elif escolha == 3:
        print(x1*x2)
    elif escolha == 4:
        if x1!=0:
            print(x1/x2)
        else:
            print("Não há divisão por 0 ")
    
    print("Como dizia minha ex, terminamos!")
    pergunta = input("Quer continuar? [S/N]").upper()
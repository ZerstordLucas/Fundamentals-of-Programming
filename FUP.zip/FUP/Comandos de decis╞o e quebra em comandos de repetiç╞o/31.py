pergunta = "S"
while pergunta == "S":
    x1 = int(input("Digite o primeiro número: "))
    x2 = int(input("Digite o segundo número: "))
    par = 0
    impar = 1
    for i in range(x1, x2+1):
        if i % 2 == 0:
            par += i
        elif i % 2 != 0:
            impar *= i

    print(f"A soma é {par} e a multiplição é {impar}")



    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()
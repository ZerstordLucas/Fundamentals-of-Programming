pergunta = "S"
while pergunta == "S":
    y = 0
    for i in range(3):
        x = float(input("Digite sua nota: "))
        if x > 0 and x <=10:
            y+=x
        else:
            y+=0
    print(y/3)
    
    pergunta = input("Quer continuar? [S/N]").upper()

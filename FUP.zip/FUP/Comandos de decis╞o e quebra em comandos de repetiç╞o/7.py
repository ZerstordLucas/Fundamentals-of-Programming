pergunta = "S"
while pergunta =="S":
    salario = float(input("Digite seu sálario: "))
    porc = float(input("Qual o valor do empréstimo? "))
    
    limite = salario*0.2
    requisitado = (salario*porc)/100
    
    if limite <= requisitado:
        print("Empréstimo concedido! 😎")
    else:
        print("Empréstimo não concedido! ")
    print("Fim")
    pergunta = input("Quer tentar sujar seu nome novamente? [S/N]").upper()
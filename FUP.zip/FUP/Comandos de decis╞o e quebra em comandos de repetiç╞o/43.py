pergunta = "S"
while pergunta == "S":
    i_novo = 99999999999999
    N_novo = ""
    i_vei = 0
    n_vei = ""
    
    continuar ="S"
    while continuar == "S":
        
        nome = input("Digite seu nome: ")
        idade = int(input("Digite sua idade: "))
        
        if idade < 0:
            break
        elif idade < i_novo:
            n_novo = nome
            i_novo = idade
        elif idade > i_vei:
            n_vei = nome
            i_vei = idade

        continuar = input("Você quer acrescentar mais uma pessoa?[S/N]").upper()
    print(n_vei)
    print(i_vei)
    print(n_novo)
    print(i_novo)
    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()



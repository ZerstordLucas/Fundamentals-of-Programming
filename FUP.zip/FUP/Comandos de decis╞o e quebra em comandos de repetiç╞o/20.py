pergunta = "S"
while pergunta == "S":
    x = float(input("Digite um número:  "))
    raiz = x **0.5

    if x < 0:
        print("Faltou aulas de matemática né?")
        continue
    elif raiz*raiz == x:
        print(f"o número é um quadrado perfeito!")
    else:
        print(f"O número NÃO é um quadrado perfeito! Paia.")


    print("Fim do teste")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

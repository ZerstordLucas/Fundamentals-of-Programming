pergunta = "S"
while pergunta == "S":
    l = []
    for i in range(0,10):
        x = int(input("Digite um número:  "))
        if x >= 0:
            l.append(x)
        else:
            continue
    l = sum(l)
    media = l/10
    print(media)

    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

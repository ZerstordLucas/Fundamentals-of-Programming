pergunta = "S"
while pergunta == "S":
    texto1 = str(input("Digite algo: "))
    texto2 = str(input("Digite algo: "))

    if texto1 < texto2:
        print(texto1,texto2)
    else:
        print(texto2,texto1)


    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

pergunta = "S"
while pergunta == "S":
    n = float(input("Digite a primeira nota:  "))
    if n < 0:
        print("Nota inválida, reiniciando processo...")
        continue
    n1 = float(input("Digite a segunda nota:  "))
    if n1 < 0:
        print("Nota inválida, reiniciando processo...")
        continue
    n2= float(input("Digite a terçeira nota:  "))
    if n1 < 0:
        print("Nota inválida, reiniciando processo...")
        continue
    
    p = input("Digite um parâmetro: [A/P]  ").upper()
    if p != "A" or "P":
        print("Parametro inválido, reiniciando processo...")
        continue
    if p == "A":
        print(  (n+n1+n2) / 3 )
    elif p == "P":
        cal = ((n*5)+(n1*3)+(n2*2))/ (n+n1+n2)
        print(f"{cal:.2f}")

    print("Fim")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

pergunta = "S"
while pergunta == "S":
    x = int(input("Digite um número: "))
    s = []
    for i in range(1, x):
        if x % i == 0:
            s.append(i)
    print(f" Os divisore são {s}")
    
    print("Fim")
    pergunta = input("Quer continuar? [S/N]").upper()

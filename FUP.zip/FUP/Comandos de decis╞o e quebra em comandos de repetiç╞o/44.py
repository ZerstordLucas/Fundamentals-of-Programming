pergunta = "S"
while pergunta == "S":
    x = input("Digite seu texto:  ")
    y = " "
    for i in x:
        if i =="A":
            y += "*"
        elif i == "a":
            y += "*"
        else:
            y += i
    print(y)
    print(y[::-1])

    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

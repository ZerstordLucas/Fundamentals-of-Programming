def comparador(t1, t2):
    if t1 == t2:
        return("As strings são iguais!")
    else:
        return("As strings não são iguais")
    
pergunta = "S"
while pergunta == "S":
    texto1 = str(input("Digite algo: "))
    texto2 = str(input("Digite algo: "))

    print(comparador(texto1,texto2))


    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

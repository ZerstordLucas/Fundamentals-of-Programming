pergunta = "S"
while pergunta == "S":
    x = float(input("Digite o primeiro número: "))
    x1 = float(input("Digite o segundo número: "))

    if x > x1:
        print(f"O maior número é {x}")
    elif x < x1:
        print(f"O maior número é {x1}")
    else:
        print("Os números são iguais")

    print("Fim da comparação")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

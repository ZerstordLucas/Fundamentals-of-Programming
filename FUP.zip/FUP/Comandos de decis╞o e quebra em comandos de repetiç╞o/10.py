pergunta = "S"
while pergunta == "S":
    dia = int(input("Digite um número de 1 a 7: "))

    if dia == 1:
        print("Domingo")
    elif dia == 2:
        print("Segunda")
    elif dia == 3:
        print("Terça=feira")
    elif dia == 4:
        print("Quarta-feira")
    elif dia == 5:
        print("Quinta-feira")
    elif dia == 6:
        print("Sexta-feira")    
    elif dia == 7:
        print("Sábado")
    print("Fim")
    pergunta = input("Quer continuar? [S/N]").upper()
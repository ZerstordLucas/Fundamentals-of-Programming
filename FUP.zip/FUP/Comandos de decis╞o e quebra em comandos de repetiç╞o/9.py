pergunta = "S"
while pergunta == "S":
    x1 = int(input("Digite um número: "))
    x2 = int(input("Digite um número: "))
    x3 = int(input("Digite um número: "))
    
    if x1 < x2 < x3 :
        print(x1, x2, x3)
    elif x1 < x3 <  x2: 
        print(x1,x3, x2) 
    elif  x2  < x1 < x3:
        print( x2, x1,x3)
    elif  x2  < x3 < x1:
        print( x2, x3,x1)
    elif x3 < x1 <  x2: 
        print(x3,x1, x2) 
    elif x3 <  x2  < x1:
        print(x3, x2, x1)

    print("FIm")
    pergunta = input("Usar novamente? [S/N]").upper()
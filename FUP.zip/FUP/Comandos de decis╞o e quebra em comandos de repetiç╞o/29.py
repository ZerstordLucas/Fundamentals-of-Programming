pergunta = "S"
while pergunta == "S":
    x = int(input("Digite um número: "))
    contador = 0
    if x == 2:
        print("É primo!")
        continue
    
    for i in range(1, x+1):
        if x % i == 0:
            contador +=1
        else:
            continue
    
    if contador == 2:
        print("É primo!")
    else:
        print("Não é primo! Paia")

    pergunta = input("Quer continuar? [S/N]").upper()

cripto = { "A":"D", "B":"E", "C":"F", "D":"G", "E":"H", "F":"I", "G":"J", "H":"K", "I":"L", "J":"M", 
          "K":"N", "L":"O", "M":"P", "N":"Q", "O":"R", "P":"S", "Q":"T", "R":"U",  "S":"V", "T":"W", 
          "U":"X", "V":"Y", "W":"Z", "X":"A", "W":"B", "Z":"C" } 


def codificador(t):
    Lcode = []
    for letra in t:
        if letra in cripto:
            Lcode.append(cripto[letra])
        else:
            Lcode.append(letra)
    alanturing = "".join(Lcode)
    return(alanturing)

pergunta = "S"
while pergunta == "S":
    x = input("Digite seu texto: ").upper()
    print(f"O texto criptografado: {codificador(x)}. Que foda né!")
    pergunta = input("Quer criptografar mais? [S/N]  ").upper()

    
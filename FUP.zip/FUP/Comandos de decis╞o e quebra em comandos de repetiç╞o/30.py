pergunta = "S"
while pergunta == "S":
    lista = [] 
    continuador = "S"
    
    while continuador == "S":
        x = int(input("Digite um número:  "))
        lista.append(x)
        continuador = input("Mais algum número? [S/N]").upper()
    
    ordem = sorted(lista)
    N_maior = max(ordem)
    contador = 0 
    
    for i in range(len(lista)):
        if lista[i] == N_maior:
            contador+= 1

    print(f"O número {N_maior} é o maior e se repitiu {contador} vezes!")
    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()
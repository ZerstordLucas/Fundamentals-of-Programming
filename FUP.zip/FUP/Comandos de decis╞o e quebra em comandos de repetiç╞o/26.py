pergunta = "S"
while pergunta == "S":
    l = []
    for i in range(0,10):
        x = int(input("Digite um número:  "))
        l.append(x)
    max = max(l)
    min = min(l)

    print(f"O maior número é {max} e o menor número é {min}")
    
    print("Fim do progama!")
    pergunta = input("Gostaria de testa novamente? [S/N]  ").upper()

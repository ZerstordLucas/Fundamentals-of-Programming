pergunta = "S"
while pergunta == "S":
    num1 = float(input("Digite um número: "))
    op = str(input("Digite a operação: [+ - * /]: "))
    num2 = float(input("Digite um número: "))

    if op == "+":
        print(num1 + num2)
    elif op == "-":
        print(num1 - num2)
    elif op == "*":
        print(num1 * num2)
    elif op == "/":
        print(num1 / num2)
    print("Fim do calculo!")
    pergunta = input("Quer aprender mais? [S/N]").upper()

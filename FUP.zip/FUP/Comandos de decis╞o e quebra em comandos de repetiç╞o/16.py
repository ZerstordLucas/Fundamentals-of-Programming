numero = 0
while numero >= 0:
    x = int(input("Digite um número: "))
    if x >= 0:
        print(x)
    else:
        print("Fim do progama")
        break
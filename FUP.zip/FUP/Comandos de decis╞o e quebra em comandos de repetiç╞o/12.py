pergunta = "S"
while pergunta == "S":
    num = int(input("Digite um número :  "))

    if num == 1:
        print("Bom Dia - Boa Tarde - Boa Noite")
    if num == 2:
        print("Por Favor :) - Com Licenca :D - Muito Obrigado ;)")
    if num == 3:
        print("Por Gentileza - Voce poderia - Desculpe")
    if num == 4:
        print("Boa Sorte - Tenha Fe")
    if num >= 5:
        print("Estudar vale muito a pena!")


    print("Fim da mensagem!")
    pergunta = str(input("Quer uma nova mensagem no seu MSN? [S/N]").upper())

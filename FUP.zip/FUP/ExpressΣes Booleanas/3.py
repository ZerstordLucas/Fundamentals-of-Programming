def validador(nome, letra):
    nova= ""
    for analis in nome:
        if  analis == "a" or analis =="e" or analis =="analis" or analis =="o" or analis =="u":
            analis = letra
            nova += analis
        elif analis == "A" or analis == "E" or analis == "I" or analis == "O" or analis == "U":
            analis = letra
            nova += analis
        else:
            nova += analis
    return(nova)

pergunta = "S"
while pergunta == "S":
    palavra = input("Digite o texto:  ")
    substituir = input("Digite a letra no qual substituira: ")
    
    print("\nSeu resultado: ")
    final = validador(palavra, substituir)
    print(final)

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama!")
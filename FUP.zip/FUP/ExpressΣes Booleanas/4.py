pergunta = "S"
while pergunta == "S":
    num = int(input("Digite um número:  "))
    if num < 0:
        print("Digite um número inteiro positivo")
        continue
    elif (num%3 == 0 and num%5 != 0) or (num%3 != 0 and num%5 == 0):
        print(True)
    else:
        print(False)
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
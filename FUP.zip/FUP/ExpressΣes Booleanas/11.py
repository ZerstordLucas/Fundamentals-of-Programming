def separador(d):
    dia = int()
    mes = int()
    ano = int()
    dia, mes, ano = d.split("/")

    if dia.isnumeric() and mes.isnumeric() and ano.isnumeric():
        return(dia, mes, ano)
    else:
        return(0, 0, 0)
    
pergunta ="S"
while pergunta == "S":
    data = input("Digite uma data no fomato DD/MM/AAAA: ")
    print(separador(data))
    pergunta = input("Gostaria de continuar? [S/N]  ").upper()
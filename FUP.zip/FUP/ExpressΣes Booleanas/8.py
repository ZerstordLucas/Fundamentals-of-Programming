x = 0
while x <= 1000:
    for i in range(1,1001):
        if i % 3 == 0 or i % 5 == 0 :
            x += i
print(x)

pergunta = "S"
while pergunta == "S":
    num = int(input("Digite um número: "))
    num1 = int(input("Digite um número: "))
    num2 = int(input("Digite um número: "))

    if num == num1 and num == num2 and num1 == num2:
        print("É triângulo equilátero")
    elif num != num1 and num != num2 and num1 != num2:
        print("É triângulo escaleno")
    else:
        print("É triângulo isosceles")
    print("Fim do teste")
    pergunta = input("\nGostaria de tentar novamente? [S/N] ").upper()
print("Fim do progama !")
pergunta = "S"
while pergunta == "S":
    ano = int(input("Digite o ano:  "))

    if (ano % 4 == 0) and (ano % 100 != 0):
        print("Ano bissexto")
    else:
        print("Ano não é bissexto!")
    print("Fim do teste!")
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
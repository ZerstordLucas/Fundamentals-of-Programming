def mdc(x1, x2):
    incio = 1
    menor = min(x1, x2)

    for i in range(1, menor +1):
        if x1 % i == 0 and x2 % i == 0:
            incio = i
    return(incio)

def mmc(x1, x2):
    return abs(x1 * x2)/mdc(x1,x2)

pergunta = "S"
while pergunta == "S":
    num = int(input("Digite o primeiro número: "))
    num1 = int(input("Digite o segundo número: "))
    print(mmc(num,num1))
    print("\nFim do teste")
    pergunta = input("Gostaria de testar novamente? [S/N] ").upper()
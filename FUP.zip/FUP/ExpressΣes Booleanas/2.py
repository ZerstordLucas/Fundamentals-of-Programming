def validador (nome):
    novo = ""
    for i in nome:
        if i == "a" or i =="e" or i =="i" or i =="o" or i =="u":
            None
        elif i == "A" or i == "E" or i == "I" or i =="O" or i =="U":
            None
        else:
            novo +=i
    return(novo)
pergunta = "S"
while pergunta =="S":
    nome = input("Digite uma palavra:  ")
    print(validador(nome))
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama!")

pergunta = "S"
while pergunta == "S":
    idade = int(input("Digite sua idade:  "))
    if idade >= 65:
        print("Pode se aposentar!")
        print("Fim do teste!")
        continue
    
    t_servico = int(input("Digite seu tempo de serviço:  "))

    if t_servico >= 30:
        print("Pode se aposentar!")
    elif idade >= 60 and t_servico >= 25:
        print("Pode se apesentar!")
    else:
        print("Não pode se aposentar!")

    print("Fim do teste!")
    pergunta = input("Gostaria de tentar novamente? [S/N] ").upper()
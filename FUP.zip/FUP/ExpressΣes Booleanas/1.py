def validador (nome):
  for i in nome:
    if nome[0] == "A" or nome[0] == "a":
      return True


pergunta = "S"
while pergunta == "S":
  nome = input("Digite um nome: ")

  if validador(nome):
    print(nome)

  print("Fim!")
  pergunta = input("Gostaria de continuar? [S/N]").upper()
print("\nFinalizando...")


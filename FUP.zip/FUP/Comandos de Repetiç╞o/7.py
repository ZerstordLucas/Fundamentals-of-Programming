def funcao(y):
  l = []
  if y > 0:
    for n in range(1,y+1):
      l.append(n)
    l=sum(l)
  else:
    for n in range(0,y-1,-1):
      l.append(n)
    l=sum(l)
  return(l)
x = int(input("Digite um número: "))
print(funcao(x))

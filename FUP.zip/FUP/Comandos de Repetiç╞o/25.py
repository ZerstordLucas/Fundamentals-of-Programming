def frac(x):
    num =0
    den = 0
    z= 0
    for i in range(1, x+1):
        num = i**2+1
        den = i+3
        z += num/den
        
    return(round(z,2))

p = int(input(""))
print(frac(p))
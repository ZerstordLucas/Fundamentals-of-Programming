def fatorial(p):
  num = 1
  for i in range(1, p +1):
    num *=i
  return(num)

def cal (y):
  import math
  from fractions import Fraction
  sf = 1
  for i in range (1 , y+1):
    sf += 1/fatorial(i)
  return(sf)

x = int(input(""))
print(cal(x))


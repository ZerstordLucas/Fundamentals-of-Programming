x = input("")
invertida = ""
for i in x[::-1]:
    invertida += i
print(invertida)
n1 = int(input("Digite um número: "))
def soma(n):
  p = 0
  l = []
  for i in range (0, n+p):
    l.append(p)
    p+=2
    
  return (sum(l))
print(soma(n1))


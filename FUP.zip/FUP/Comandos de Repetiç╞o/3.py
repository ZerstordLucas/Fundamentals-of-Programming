y = 0
for x in range(0,10):
  p = int(input("digite um número: "))
  y+= p
print(y)

def calc(y):
  from fractions import Fraction
  sf = Fraction()
  for i in range(1, y+1):
    sf += Fraction(1, i) 
  return(float(sf))
x =  int(input(""))
print(round(calc(x),2))
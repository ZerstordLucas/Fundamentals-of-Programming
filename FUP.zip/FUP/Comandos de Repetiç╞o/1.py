for x in range(0,100):
    print(x+1)
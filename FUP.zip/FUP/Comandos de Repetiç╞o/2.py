for x in range(0,100000, 1000):
  print(x+1000)
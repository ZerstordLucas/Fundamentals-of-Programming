n = int(input("Digite um número: "))
l = []
if n>0:
  for i in range(0,n+1):
    l.append(i)
  print(sum(l))
else:
  for i in range(0, -1, -1):
    l.append(i)
    print(sum(l))


#Falta essa 

def esquema(x):
  for i in range (0, x-1):
      print("!")
      for j in range(0, i+1):
          print("!",end="")
  print('!')
  for l in range(x-1, 0, -1):
    for m in range(0,l):
      print("!",end="")
    print("")
  
qntd = int(input("Digite um número: "))
esquema(qntd)
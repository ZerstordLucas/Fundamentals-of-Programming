def fatorial(p):
  num= 1
  for i in range(1 , p+1):
    num *= i
  return(num)
def soma(x):
  fac = fatorial(x)
  resultado = 0
  fac_t = str(fac)
  for i in fac_t:
    t = int(i)
    resultado += t
  return(resultado)
n = int(input())
print(soma(n))
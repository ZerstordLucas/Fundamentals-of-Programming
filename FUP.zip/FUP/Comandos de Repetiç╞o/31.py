t1 = input("")
t2 = input("")
x  = int(input(""))

for i in range (0, x):
    print(t1 + t2)
y = 0
v = []
for x in range(0,10):
  p = float(input("Digite um número: "))
  v.append(p)
  y+=p
v = len(v)
v = int(v)
print(y/v)

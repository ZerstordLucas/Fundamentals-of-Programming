def esquema(x):
  p = 1
  for i in range (0, x):
      print()
      for j in range(0, i+1):
          print(p,end=" ")
          p += 1
  print()
qntd = int(input("Digite um número: "))
esquema(qntd)
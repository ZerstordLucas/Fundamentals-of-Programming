x = 10
for i in range (0,x):
    print("Meu curso eh show.")
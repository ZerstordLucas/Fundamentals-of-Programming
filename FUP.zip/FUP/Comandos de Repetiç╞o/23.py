for i in range(1,10):
  for z in range (1,10):
    print(f"{i} + {z} = {i+z}")
def cal(fac):
  num = 1
  for i in range(1, fac +1):
    num *=i
  return(num)
valor = int(input("Digite um número: "))
print(cal(valor))



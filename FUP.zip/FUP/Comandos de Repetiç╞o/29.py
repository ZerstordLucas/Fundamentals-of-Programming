x = int(input(""))
if x > 0 :
    for i in range(0, x):
        print("Estou sabendo Progamar haha.")
else:
    print("Por favor digite um número maior que 0")
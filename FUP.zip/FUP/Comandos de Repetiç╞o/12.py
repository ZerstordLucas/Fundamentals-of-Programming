def fatorial(p):
  num = 1
  for i in range(1, p +1):
    num *=i
  return(num)

def bino(n, k):
  if n>= k >= 0:
    bin_nume = fatorial(n)
    bin_deno = fatorial(k) * fatorial(n-k) 
    result = bin_nume/bin_deno
    return(result)
x1 = int(input("Digite um valor para n: "))
x2 = int(input("Digite um valor para K: "))


print(bino(x1,x2))



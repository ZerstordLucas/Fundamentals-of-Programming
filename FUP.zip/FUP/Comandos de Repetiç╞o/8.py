n = int(input("Digite um número: "))
im = 1
for i in range(0, n):
  if im %2 !=0:
    print(im)
    im+= 2
    

def fatorial(y):
    num = 1
    for i in range(1, y+1):
        num*=i
    return(num)

def cal(x,n):
    resultado = 0
    for i in range(n):
        formula = ((-1)**i/ fatorial(2*i+1)) * (x**(2*i+1))
        resultado += formula

    return(resultado)

a = float(input(""))
b = int(input(""))
resu = round(cal(a,b))
print(f"{resu:.12f}")


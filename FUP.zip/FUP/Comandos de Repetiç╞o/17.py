x = int(input(" "))
for i in range (0, x):
  print("=",end="")

#Faça uma função que receba um inteiro x e um inteiro não-negativo n e, usando laço de 
#repetição, calcule x^n e retorne o resultado.


def cal(x1,x2):
  for i in range(x1,x2):
    if x2 >= -1:
      print(x1**x2)
    else:
      None
y1 = int(input("Digite um valor para x: "))
y2 = int(input("Digite um valor para n: "))
cal(y1,y2)







num = 0
den = 0
fra = 0
for c in range(1 ,50+1):
  num = (c*2)-1
  den = c
  z = num/den
  
  fra += z

print(f"{fra:.10f}")
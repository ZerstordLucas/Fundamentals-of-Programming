def fibo(x):
  f1 = 1
  f2 = 1
  if (x<0) or (x==0):
    return(0)
  if (x==1) or (x==2):
    return(1)
  else:
    for i in range (2, x):
      f3 = f1 + f2
      f2 = f1
      f1 = f3
    return(f3)
n = int(input("Digite um número: "))
print(fibo(n))

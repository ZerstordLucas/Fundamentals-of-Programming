n = int(input("Digite um numero: "))
if n>0:
  for i in range(1,n+1):
    print(i)
  
else:
  for i in range(0, n-1, -1):
    print(i)


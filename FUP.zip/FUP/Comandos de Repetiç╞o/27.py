def cal(x):
    num = 1
    for i in range(x-1, 0, -1):
        print(i)
        num = num * pow(x,i)
    return(num)
      
num = int(input(""))
print(cal(num))

#Não consegui fazer com que o output fosse correto


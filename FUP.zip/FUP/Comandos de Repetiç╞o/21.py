def piradinha(x):
  for i in range(1, x+1):
    print(f"{' '*(x-i)}{' *'*i}"[1:])

qntd = int(input(""))
piradinha(qntd)
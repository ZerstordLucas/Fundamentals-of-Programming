x = int(input(""))
for i in range(1, x+1):
    z=1
    for j in range(1, i+1):
        print(z, end=" ")
        z= z*(i-j) //j
    print()











#passei 2 horas usando um crl de outras formas de sair certo
#porém o jovem digitou errado a divisão inteira "//i" ao invés
#de "//j".
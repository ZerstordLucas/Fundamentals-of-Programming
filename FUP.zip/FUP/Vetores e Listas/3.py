pergunta = "S"
while pergunta == "S":
    
    lista = []
    while lista == lista[0:5]:
        x = int(input("Digite um número: "))
        lista.append(x)
   
    for i in lista:
        print(i)
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print ("Fim do progama! 😒")
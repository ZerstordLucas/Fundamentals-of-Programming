def saber_multiplos (x,l):
    l_multiplo = []
    for i in l:
        if i % x == 0:
            l_multiplo.append(i)
    return list(set(l_multiplo))

pergunta = "S"
while pergunta == "S":
    lista = []
    continuar = "S"
    while continuar == "S":
        num = int(input("Digite um valor para adicionar a lista:\n"))
        lista.append(num)
        continuar = input("Deseja digitar mais um número? [S/N]\n").upper()
    Num_R_multiplo = int(input("Digite o valor que será a ordem: "))
    
    print(f"A lista é {lista} e a ordem é {Num_R_multiplo}")
    print(saber_multiplos(Num_R_multiplo, lista))
    
    pergunta = input("Gostaria continuar? [S/N] ").upper()
print("Fim")

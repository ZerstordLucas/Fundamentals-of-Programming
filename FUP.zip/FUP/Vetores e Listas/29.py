def ordenador (x):
    for num in range(len(x)):
        
        for num2 in range(num+1, len(x)):
            
            if x[num2] > x[num]:
                x[num], x[num2] =  x[num2], x[num]

    return x

pergunta = "S"
while pergunta == "S":
    
    vetor = []
    continuaADD = "S"
    while continuaADD == "S":
        vetor.append(float(input("Digite um número no conjunto dos reais para adicionar ao vetor:\n")))
        continuaADD = input("Quer adicionar mais? [S/N]\n").upper()
    
    print(ordenador(vetor))
    
    pergunta = input("Gostaria de continuar? [S/N]\n").upper()
print("Finalizando o progama...")
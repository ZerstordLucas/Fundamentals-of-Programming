pergunta = "S"
while pergunta == "S":
    
    lista = []
    soma = 0
    while lista == lista[0:14]:
        num = int(input("Digite um número: "))
        lista.append(num)
    
    
    for num_impar in lista:
        if num_impar % 2 == 1:
            print(num_impar)
            soma += num_impar
    print (soma)
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama! 😒")
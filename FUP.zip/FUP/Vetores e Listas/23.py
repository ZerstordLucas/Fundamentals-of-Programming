def primo_teste(x):
    contador = 0
    if x == 2:
        return(x)
    for i in range(1, x+1):
        if x % i == 0:
            contador +=1
        else:
            continue
    if contador == 2:
        return(x)

def localizar_primo(y):
    l_primo = []
    for i in range(len(y)):
        if primo_teste(y[i]):
            print(f"O número {y[i]} é primo e está na posição {i}")
            l_primo.append(y[i]), l_primo.append(i)
    return(l_primo)

pergunta = "S"
while pergunta == "S":
    lista = []
    for i in range(10):
        num = int(input("Digite um número para preencher o vetor: "))
        lista.append(num)
    print (localizar_primo(lista))
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando ...")
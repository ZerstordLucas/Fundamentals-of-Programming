pergunta = "S"
while pergunta == "S":
    texto = input("Digite um texto: ")
    
    if texto.isalpha():
        texto = texto.lower()
        vetor_letras = []
        
        for letra in texto:
            if letra not in vetor_letras:
                vetor_letras.append(letra)
    else:
        print("Digite um texto sem conter números ou caractere especial")
        continue

    print(len(vetor_letras))

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama!")
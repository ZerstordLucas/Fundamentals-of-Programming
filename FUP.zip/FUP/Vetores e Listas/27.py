def organizador(x):
    compacto = []
    for num in x:
        if num != 0:
            compacto.append(num)
    return compacto

pergunta = "S"
while pergunta == "S":
    vetor = []
    
    vetorContinuar = "S"
    while vetorContinuar == "S":
        vetor.append(int(input("Digite uma posicao: ")))
        vetorContinuar = input("Adicionar mais uma posição? [S/N] ").upper()
    
    print(f"O vetor adicionador é: {vetor};"
          f"O vetor organizado é {organizador(vetor)}")
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando...")
    
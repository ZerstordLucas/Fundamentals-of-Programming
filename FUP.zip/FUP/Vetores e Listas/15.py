pergunta = "S"
while pergunta == "S":
    vetor = []
    for i in range(10):
        num = int(input("Digite um número para preencher o vetor: "))
        vetor.append(num)
    
    repetidos = []
    for n in range(len(vetor)):
        for i in range(n +1 , len(vetor)):
            if vetor[n] == vetor[i]:
                repetidos.append(vetor[n])
    repetidos = list(set(repetidos))

    print(f"O vetor gerado pelo usuário é {vetor}.")
    print(f"Os númeors que são repetidos no vetor é {repetidos}") 
    pergunta = input("Gostaria de continuar? [S/N]").upper()
print("Fim!")

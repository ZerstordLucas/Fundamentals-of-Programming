pergunta = "S"
while pergunta == "S":
    
    lista = []
    while lista == lista[0:9]:
        x = int(input("Digite um número: "))
        lista.append(x)
    
    for i in lista[::-1]:
        print(i)
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print ("Fim do progama! 😒")
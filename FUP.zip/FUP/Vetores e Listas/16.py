pergunta = "S"
while pergunta == "S":
    lista = []
    continuar = "S"
    while continuar == "S":
        num = int(input("Digite um valor para adicionar a lista:\n"))
        lista.append(num)
        continuar = input("Deseja digitar mais um número? [S/N]\n").upper()
    L_SemRepet = []
    for i in lista:
        if lista.count(i) == 1:
            L_SemRepet.append(i)
    print(L_SemRepet)
    pergunta = input("Gostaria continuar? [S/N] ").upper()
print("Fim")
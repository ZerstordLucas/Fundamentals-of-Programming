pergunta = "S"
while pergunta == "S":
    lista = [] 
    for i in range(70):
        lista.append((i+5*i) % (i+1))
    print(lista)
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando ...")
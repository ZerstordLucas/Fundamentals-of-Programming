def subtrair(x,y):
    l_Final = []
    for i in range(len(x)):
        l_Final.append(x[i] - y[i])   
    return l_Final

pergunta = "S"
while pergunta == "S":
    lista_Num1 = []
    lista_Num2 = []
    continuar = 'S'
    while continuar == 'S':
        num = int(input("Digite um número para primeira lista: "))
        num1 = int(input("Digite um número para segunda lista: "))
        lista_Num1.append(num),lista_Num2.append(num1)
        continuar = input("Gostaria de digitar mais algum número? [S/N]").upper()

    print(f"A primeira lista é {lista_Num1} e a segunda lista é {lista_Num2}")
    print(f"A subtração por cada posição do índice é {subtrair(lista_Num1,lista_Num2)}\n")
    pergunta = input("Gostaria de continuar? [S/N]\n").upper()
print("Fim!")
A = [1, 0, 5, -2, -5, 7]
soma = sum(A[0:1] + A[5:6])
A[3] = -89
print (soma)
for numero in A:
    print (numero)  

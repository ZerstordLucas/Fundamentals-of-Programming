def uniao (x,y):
    inter = []
    for numx in x:
        inter.append(numx)
    for numy in y:
        if numy not in inter:
            inter.append(numy)
    return(inter)

pergunta = 'S'
while pergunta == 'S':
    vetor1 = []
    vetor2 = []
   
    print("/"*30)
    print("Preencha com números o vetor 1")
    vetor1_pergunta = "S"
    while vetor1_pergunta == "S":
        entrada1 = int(input("Adicione um valor para o vetor 1:\n"))
        vetor1.append(entrada1)
        vetor1_pergunta = input("Quer adicionar mais ao vetor 1? [S/N]\n").upper()
   
    print("/"*30)
    print("Agora para o vetor 2")
    Vetor2_Pergunta = "S"
    while Vetor2_Pergunta == "S":
        entrada2 = int(input("Adicione um valor para o vetor 2:\n"))
        vetor2.append(entrada2)
        Vetor2_Pergunta = input("Quer adicionar mais ao vetor 1? [S/N]\n").upper()
   
    print("/"*30)
    print(f"Os vetores 1 e 2 são respectivamente:\n"
          f"vetor 1 - {vetor1}\n"
          f"vetor 2 - {vetor2}\n"
          f"A união é: {uniao(vetor1,vetor2)}")
    
    pergunta = input("Gostaria de continuar no progama? [S/N]\n").upper()
print("Fim do progama!")
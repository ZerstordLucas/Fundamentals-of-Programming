pergunta = "S"
while pergunta == "S":
    
    lista = []
    while lista == lista[0:14]:
        num = int(input("Digite um número: "))
        lista.append(num)
    print(f"O menor valor é {min(lista)} e o maior é {max(lista)}")
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama! 😒")
pergunta = "S"
while pergunta == "S":
    vetor = []
    for i in range(12):
        num = int(input("Digite um número inteiro:\n"))
        if num not in vetor:
            vetor.append(num)
        else:
            print("O número digitado é já está no vetor, por favor")
            continue

    print(f"O vetor feito pelo usuário é {vetor}")
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando o progama....")
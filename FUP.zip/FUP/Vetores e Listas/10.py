pergunta = "S"
while pergunta == "S":
    
    lista = []
    while lista == lista[0:19]:
        num = int(input("Digite um número: "))
        if num > 0: 
            lista.append(num)
        else:
            lista.append(0)
    print(lista)
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama! 😒")
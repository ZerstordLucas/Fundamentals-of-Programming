def encontrar(L_aluno, aluno):
    l_aluno_minus = []
    aluno_minus = aluno.lower()
    for aluno in L_aluno:
        l_aluno_minus.append(aluno.lower())
    
    contador = 0
    for i in range(len(l_aluno_minus)):
        for j in range(len(aluno_minus)):
            if aluno_minus[j] == l_aluno_minus[i][j]:
                return i 

pergunta = "S"
while pergunta == "S":
    
    lista_de_alunos = []  
    add_aluno = "S"
    while add_aluno == "S" and len(lista_de_alunos) != 5:
        if len(lista_de_alunos) != 5:
            lista_de_alunos.append(input("Digite o nome do aluno:\n"))
        else:
            break
        add_aluno = input("Quer adicionar mais? [S/N]\n").upper()

    pesquisa_aluno = input("Digite o nome do aluno que quer encontrar:\n")
    if len(pesquisa_aluno) < 3 :
        print("Por favor digite pelo menos as 3 primeiras letras do nome.")
        continue
    
    indice_Aluno_lista = encontrar(lista_de_alunos,pesquisa_aluno)
    print(indice_Aluno_lista)
 
    pergunta = input("Gostaria de reiniciar o progama? [S/N] ").upper()
print("Finalizando o progama...")
import random
pergunta = 'S'
while pergunta == 'S':
    num = random.seed(int(input("Digite um número para a semente: ")))
    lista = []
    for i in range(12):
        lista.append(random.randint(-10,10))
    soma = 0
    contador = 0
    for j in range(len(lista)):
        if lista[j] >= 0:
            soma += lista[j]
        else:
            contador += 1

    print(f"O vetor gerado foi {lista}\n"
          f"A soma de todos os valores positivos é {soma}\n"
          f"E a qntd de números negativos é {contador}")

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando progama...")

pergunta = "S"
while pergunta == "S":
    
    lista = []
    while lista == lista[0:14]:
        num = int(input("Digite um número: "))
        lista.append(num)
    
    for num_par in lista:
        if num_par % 2 == 0:
            print(num_par)
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama! 😒")
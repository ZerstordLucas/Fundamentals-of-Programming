def media(x):
    return (sum(lista)/len(lista))

def desvio(x):
    soma = 0
    for i in x:
        soma += (i - media(x))**2
    soma = (soma/len(lista))**0.5
    return (soma)

def contador(x):
    cont = 0
    for i in x:
        if i<7:
            cont +=1
    return(cont)

pergunta = "S"
while pergunta == "S":
    
    lista = []
    while lista == lista[0:14]:
        num = float(input("Digite um número: "))
        if num > 0: 
            lista.append(num)
        else:
            lista.append(0)
    print(f"A média é {media(lista)}, o desvio é {desvio(lista)} e há {contador(lista)} abaixo da média.")
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama! 😒")
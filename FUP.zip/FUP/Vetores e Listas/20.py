pergunta = 'S'
while pergunta == 'S':
    l = []
    for i in range(100):
        num = int(input("Digite um número: "))
        l.append(num)
    print("Informações do código:\n 0 - finaliza progama;\n 1 - apresenta lista em ordem direta;\n 2 - apresenta lsta em ordem inversa")
    cod = -1
    while cod not in[0,1,2]:
        cod = int(input("Digite o código: "))
        if cod not in[0,1,2]:
            print("Inválido")
            continue
        elif cod == 1:
            print(l)
        elif cod == 2:
            print(l[::-1])
    if cod == 0:
        break
        
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando progama...")
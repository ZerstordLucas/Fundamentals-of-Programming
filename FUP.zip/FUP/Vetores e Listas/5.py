def quadrado(x):
    L_quad = []
    for i in x:
        i = i**2
        L_quad.append(i)
    return L_quad

pergunta = "S"
while pergunta == "S":
    
    L_Num = []
    while L_Num == L_Num[0:9]:
        num = int(input("Digite um número: "))
        L_Num.append(num)
    
    for num in L_Num:
        print (num)
    
    for num_quad in quadrado(L_Num):
        print (num_quad)
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama!😎👌")
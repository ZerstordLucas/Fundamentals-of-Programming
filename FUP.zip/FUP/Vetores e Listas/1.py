def mes_escrito(x):
    x = int(x)
    lista = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", 
             "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
    return lista[x-1]

def data_escrita(d, m, a):
    nom_mes = mes_escrito(m)
    return (f"{d} de {nom_mes} de {a}!")

pergunta = "S"
while pergunta == "S":
    data = input("Digite uma data no formato 00/00/0000: ")
    if data.isdigit():
        dia, mes, ano = data.split("/")
        dia = int(dia)
        mes = int(mes)
        ano = int(ano)
        if dia < 1 or dia >31 or mes < 1 or mes > 12 or ano < 0:
            print ("Data inválida")
        else:
            print(data_escrita(dia,mes,ano))
    else:
        print("Digite somente números!")
        continue
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama! 😎👌")

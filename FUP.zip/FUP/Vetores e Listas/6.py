pergunta = "S"
while pergunta == "S":
    
    lista = []
    while lista == lista[0:8]:
        num = int(input("Digite um número: "))
        lista.append(num)
    
    indice1 = int(input("Digite um número de 1 a 10 para escolher a 1° posição: "))
    indice2 = int(input("Digite um número de 1 a 10 para escolher a 2° posição: "))
    
    print(lista[indice1-1] + lista[indice2-1])
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim do progama! 😎👌")
pergunta = "S"
while pergunta == "S":
    lista = [] 
    for i in range(100):
       if i % 7 != 0 or  i % 10 == 7:
           lista.append(i)
    print(lista)
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando ...")
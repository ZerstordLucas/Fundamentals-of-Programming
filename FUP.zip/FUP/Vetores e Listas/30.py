def seguiment(vet, seg):
    contador = 0
    posicao = []
    for i in range(len(vet)):
        if vet[i] == seg[0]:
            if vet[i+1] == seg[1]:
                if vet[i+2] == seg[2]:
                    contador +=1
                    posicao.append(i)
        
    if contador == 0:
        for j in range(len(seg)):
            posicao.append(-1)
       
    return (posicao)


pergunta = "S"
while pergunta == "S":
    vetor = []
    seguimento = []
    for num in range(10):
        vetor.append(int(input("Digite um número para adicionar ao vetor: ")))
    for num_seg in range(3):
        seguimento.append(int(input("Digite o valores para serem o seguimento: ")))

    print(f"O vetor digitado é: {vetor}, e o seguimento foi: {seguimento}")
    print("/"*50)
    print(f"O seguimento igual máximo está nas posições{seguiment(vetor,seguimento)}")

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando o progama...")
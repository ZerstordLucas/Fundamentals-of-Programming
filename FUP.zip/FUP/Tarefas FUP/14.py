#Entrada
num = int(input(""))

#Condição
if int(num) >=1000 and int(num) <= 9999:
  linhas = str(num)
  
  #Saída
  print (str(linhas[0]))
  print (str(linhas[1]))
  print (str(linhas[2]))
  print (str(linhas[3]))
  
else:
  print("Inválido")
#Entrada
v1 = float(input(""))
v2 = float(input(""))

#Cálculo
D = float((v1**2 + v2**2)**0.5)

#Saída
print ("%.2f" % D)
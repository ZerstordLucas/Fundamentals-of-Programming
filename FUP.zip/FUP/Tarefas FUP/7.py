#Entrada
temp_celsius = float(input(""))

#Cálculo
fahrenheit = float(temp_celsius*(9/5)+32)

#Saída
print ("%.2f"% fahrenheit)
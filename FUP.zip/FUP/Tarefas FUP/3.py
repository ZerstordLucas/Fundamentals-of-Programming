#Entrada
numero = int(input(""))
#Cálculos
antecessor = int(numero-1)
sucessor = int(numero+1)
#Saída
print(antecessor)
print(sucessor)
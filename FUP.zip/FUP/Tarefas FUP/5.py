#Importação de Biblioteca
import math

#Entrada
raio = float(input(""))

#Valores
π = float(3.14159265)
fracao = float(1.3333333333)

#Cálculos
volume = float(fracao*π*raio**3)
area = float(4*π*raio**2)

#Saída
print ("%.2f"% volume)
print ("%.2f"% area)
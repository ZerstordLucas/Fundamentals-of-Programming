#Entrada
numero = float(input(""))

#Cálculos
num_quad = float(numero**2)

#Saída
print ("%.2f"% num_quad)

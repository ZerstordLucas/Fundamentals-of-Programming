#Entrada
k = float(input(""))

#Cálculos
m = float(k/3.6)

#Saída
print ("%.2f"% m)


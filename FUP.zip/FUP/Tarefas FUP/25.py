#Entrada
txt = input("")
#Saída
print("".join(txt.split()))



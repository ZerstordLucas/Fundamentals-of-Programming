#Entrada
num = int(input(""))

num = str(num)

num_invert = (num[::-1])
print (int(num_invert))
#Entrada
txt = input("")
txt = txt.upper()

#Saída
print((txt))
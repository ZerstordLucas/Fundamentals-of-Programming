#Entrada
texto = str(input(""))
limitant1 = int(input(""))
limitant2= int(input(""))

#Saída
print(texto[limitant1:limitant2])

#OBS:Está começando do [0] e não em [1].
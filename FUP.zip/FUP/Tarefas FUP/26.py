#OBS: NÃO CONSEGUI CRIAR SEM PESQUISAR O FORMATO DE CRIAÇÃO DE FUNÇÃO
#Função 
def substituir(txt, letra1, letra2):
    txtalterado = ""
    for letra in txt:
        if letra == letra1:
            txtalterado  += letra2
        else:
            txtalterado  += letra
    return txtalterado 

txt = input(" ") #texto
l1 = input("") #letra que quer alterar
l2 = input("") #letra que irá substituir

txtalterado = substituir(txt, l1, l2)

#Saída
print(txtalterado )
print(l1)
print(l2)


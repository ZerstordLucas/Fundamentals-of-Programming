#Entrada
valor1 = float(input(""))
valor2 = float(input(""))
valor3 = float(input(""))

#Cálculos
soma = float(valor1**2 + valor2**2 + valor3**2)
quad_soma = float((valor1+valor2+valor3)**2)

#Saída
print ("%.2f" % soma)
print ("%.2f"% quad_soma)

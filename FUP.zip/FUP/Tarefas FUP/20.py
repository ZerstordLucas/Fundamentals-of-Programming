#Entrada
texto = str(input(""))

#Saída
print (len(texto))

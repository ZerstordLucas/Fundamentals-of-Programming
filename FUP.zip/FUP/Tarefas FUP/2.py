#Entradas de valores
altura = float(input(""))
base = float(input(""))
#Cálculos
area = float(base*altura)
x = float(base+altura)
perimetro = float(base+altura+x)
#Saída
print ("%.2f"% area)
print ("%.2f"% perimetro)

#Entrada
lado = float(input(""))
#Cáculos
area = float(lado**2)
#Saída
print("%.2f"% area)
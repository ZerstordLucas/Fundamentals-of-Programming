#Criando uma função
def convert(segundos):
    segundos = segundos % (24*3600)
    horas = segundos // 3600
    segundos %= 3600
    minutos = segundos // 60
    segundos %= 60
    
    return int(horas),int(minutos),int(segundos)

#Entrada 
valor = int(input(""))
#Saída
print (convert(valor))

#OBS: não consegui com que a saída fosse em 3 linhas diferentes,
#     como pedido na tarefa
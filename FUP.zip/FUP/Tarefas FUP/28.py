
string1 = input("")
string2 = input("")
n = string1.endswith(string2)
print(n)


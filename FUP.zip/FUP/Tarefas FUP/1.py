#Entrada
dollar = float(input(""))
cambio = float(5.27)
#Cálculos
real = float(dollar*cambio)
#Saída
print ("%.2f"%real)

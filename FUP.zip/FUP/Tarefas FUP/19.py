#Entrada
texto = str(input(""))

#Saída
print(texto)
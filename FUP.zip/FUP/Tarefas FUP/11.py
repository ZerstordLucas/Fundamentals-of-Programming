#Entrada
salario = float(input(""))

#Cálculos
porcentagem = float(21.37/100)
aumento = float(salario*porcentagem)
novo_salario = float(salario+aumento)

#Saída
print ("%.2f" % novo_salario)
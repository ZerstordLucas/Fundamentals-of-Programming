#Entrada
a1 = float(input(""))
a2 = float(input(""))
a3 = float(input(""))
premio = float(input(""))
SomaA = float(a1+a2+a3)

#Cálculos porcentagem de cada amigo
porcA1 = float((a1*100)/SomaA)
porcA2 = float((a2*100)/SomaA)
porcA3 = float((a3*100)/SomaA)

#Cálculos do prêmio proporcional ao investimento
valorA1 = float((porcA1)*premio/100)
valorA2 = float((porcA2)*premio/100)
valorA3 = float((porcA3)*premio/100)

#Saída
print("%.2f" % valorA1)
print("%.2f" % valorA2)
print("%.2f" % valorA3)
#Leia um ângulo em graus e apresente-o convertido em radianos. 
# A fórmula de conversão é: R = G * π/180 , sendo G o ângulo em graus e R em radianos.

#Entrada
G = float(input(""))

#Dados
π = float(3.14159265)
#Calculos
R = (G*π/180)

#Saída
print("%.2f"% R)

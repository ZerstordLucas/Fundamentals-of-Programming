#Entrada
txt = input("")
txt = txt.lower()

#Saída
print(txt)
#Entrada
numero = int(input(""))

#Cálculos
cem = int(numero/100)
numero = numero - (cem*100)

cinq = int(numero/50)
numero = numero - (cinq*50)

vinte = int(numero/20)
numero = numero - (vinte*20)

dez = int(numero/10)
numero = numero - (dez*10)

cinco = int(numero/5)
numero = numero - (cinco*5)

dois = int(numero/2)
numero = numero - (dois*2)

um = (numero)

print (cem, cinq, vinte, dez, cinco, dois, um)


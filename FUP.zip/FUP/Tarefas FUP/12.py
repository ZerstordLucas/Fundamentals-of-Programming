#Entrada
premio = float(input(""))

#Infomações 
ganhador1 = 54/100 #porcentagem que não irá receber
ganhador2 = 68/100 #porcentagem que não irá receber
ganhador3 = 78/100 #porcentagem que não irá receber

#Cálculos
premio1 = float(premio-(premio*ganhador1))
premio2 = float(premio-(premio*ganhador2))
premio3 = float(premio-(premio*ganhador3))

#Saída
print("%.2f" % premio1)
print("%.2f" % premio2)
print("%.2f" % premio3)

def infoestoque():
    print("\nEm estoque atualmente:")
    for item in estoque:
        print(f"ID: {item['id']}, Nome: {item['nome']}, Quantidade: {item['qty']}")

pergunta = "S"
while pergunta == "S":
    estoque = [
        {'id': 1, 'nome': 'Item1', 'preco': 10.0, 'qty': 50},
        {'id': 2, 'nome': 'Item2', 'preco': 15.0, 'qty': 30},
        {'id': 3, 'nome': 'Item3', 'preco': 20.0, 'qty': 40},
        {'id': 4, 'nome': 'Item4', 'preco': 25.0, 'qty': 20},
        {'id': 5, 'nome': 'Item5', 'preco': 30.0, 'qty': 25},
    ]

    while True:
        infoestoque()
        dado_estoque = int(input("ID produto: "))
        print("Pressione 0 para sair.")
        if id == 0: break
        for item in estoque:
            if item['id'] == dado_estoque:
                qntd = int(input("Quantidade desejada: "))
                if qntd <= item['qty']:
                    item['qty'] -= qntd
                    print(f"Executado! Total: R${qntd * item['preco']:.2f}")
                else:
                    print("Não executado, em falta no estoque.")
                break
        else:
            print("Não executado, em falta no estoque.")

    pergunta = input("Gostaria de continuar? [S/N]  ").upper()
print("Finalizando programa...")


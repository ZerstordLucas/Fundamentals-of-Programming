def organiza_data(dia, mes, ano):
    return {'dia': dia, 'mes': mes, 'ano': ano}

def organiza_hora(hora, minuto, segundo):
    return {'hora': hora, 'minuto': minuto, 'segundo': segundo}

def organiza_compromisso(data, horario, texto):
    return {'data': data, 'horario': horario, 'texto': texto}

def datold(data1, data2):
    if data1['ano'] < data2['ano']:
        return True
    elif data1['ano'] == data2['ano']:
        if data1['mes'] < data2['mes']:
            return True
        elif data1['mes'] == data2['mes']:
            if data1['dia'] < data2['dia']:
                return True
    return False

def horariold(horario1, horario2):
    if horario1['hora'] < horario2['hora']:
        return True
    elif horario1['hora'] == horario2['hora']:
        if horario1['minuto'] < horario2['minuto']:
            return True
        elif horario1['minuto'] == horario2['minuto']:
            if horario1['segundo'] < horario2['segundo']:
                return True
    return False

pergunta = "S"
while pergunta == "S":

    n = int(input("Digite a quantidade de compromissos: "))

    compromissos = []
    for i in range(n):
        dia = int(input("Digite o dia do compromisso: "))
        mes = int(input("Digite o mês do compromisso: "))
        ano = int(input("Digite o ano do compromisso: "))
        data = organiza_data(dia, mes, ano)

        hora = int(input("Digite a hora do compromisso: "))
        minuto = int(input("Digite o minuto do compromisso: "))
        segundo = int(input("Digite o segundo do compromisso: "))
        horario = organiza_hora(hora, minuto, segundo)

        texto = input("Digite o texto do compromisso: ")

        compromisso = organiza_compromisso(data, horario, texto)
        compromissos.append(compromisso)

    compromissos.sort(key=lambda x: (x['data']['ano'], x['data']['mes'], x['data']['dia'], x['horario']['hora'], x['horario']['minuto'], x['horario']['segundo']))

    for compromisso in compromissos:
        print("Data:", compromisso['data']['dia'], "/", compromisso['data']['mes'], "/", compromisso['data']['ano'])
        print("Horário:", compromisso['horario']['hora'], ":", compromisso['horario']['minuto'], ":", compromisso['horario']['segundo'])
        print("Texto:", compromisso['texto'])
        print()

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando programa...")
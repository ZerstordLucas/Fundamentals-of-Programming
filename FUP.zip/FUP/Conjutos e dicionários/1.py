pergunta = "S"
while pergunta == "S":
    dicionario = {}

    dicionario["nome"] = input("Digite seu nome: ")
    dicionario["idade"] = int(input("Digite sua idade: "))
    dicionario["endereço"] = input("Digite seu endereço: ")
    print(dicionario)

    pergunta = input("Gostaria de continuar? [S/N] ")
print("Finalizando programa...")
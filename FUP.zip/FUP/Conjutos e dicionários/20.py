def buscar_nome (lista, buscador):
    lista = []
    for nomes, dados in lista.items():
        if buscador in nomes:
            lista.append(nomes)
    return lista

def busca_mes (lista, buscador):
    lista = []
    for nomes, dados in lista.items():
        dia,mes,ano = dados["data"].split("/")
        if buscador == mes:
            lista.append(nomes)
    return lista

def expressar_dado (lista):
    for nome, dados in lista.items():
        print(nome, dados["telefone"], dados["email"])


def expressar_tudo (lista):
    for nome, dados in lista.items():
        print(nome, dados)

pergunta = "S"
while pergunta == "S":
    agenda = {}

    adicionar_contato = "S"
    while adicionar_contato == "S":
        nome = input("Digite o nome do contato: ")
        
        email = input("Digite o email do contado: ")
        if "@" not in email:
            print("Reescreva o email corretamente.")
            continue
        
        endereco = input("Digite o endereço do contato: ")
        
        telefone = int(input("Digite o telefone do contado: "))
        if len(str(telefone)) != 11:
            print("Digite o telefone corretamente. DDD 9 Numero")
            continue
        
        data = input("Digite a data de nascimento do contado:")
        if data.split("/") != 2 and len(data) != 10 and data.isnumeric():
            print("Digite a data corretamente, no formato DD/MM/AAAA.")
            continue
        
        adiconal = input("Digite algo adicional sobre o contato: ")

        agenda[nome] = {
            "email" : email, "endereco" : endereco, "telefone": telefone,
            "data": data, "adiconal": adiconal
        }
        adicionar_contato = input("Adicionar mais um contato: [S/N] ").upper()

    interface = 2
    while interface != 0:
        print("Menu principal:")
        print("Pressione 1 para apresentar os contatos.\n"
              "Pressione 2 para apresentar os contados detalhados\n"
              "Pressione 0 para finalizar o programa.")
        interface = int(input("Qual opção?"))

        if interface == 1:
            expressar_dado(agenda)
        elif interface == 2:
            expressar_tudo(agenda)
        elif interface == 0:
            break

    if interface == 0:
        pergunta == "N"
        break
    else:
        pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando programa...") 
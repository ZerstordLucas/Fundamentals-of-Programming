pergunta = "S"
while pergunta == "S":
    info_pessoas = []
    dado_pessoa = {}
    for dados in range(5):
        dado_pessoa["nome"] = input(f"Digite o nome da pessoa {dados+1}:\n")
        dado_pessoa["endereço"] = input(f"Digite o endereço da pessoa {dados+1}:\n")
        dado_pessoa["telefone"] = int(input(f"Digite o número telefone da pessoa {dados+1}:\n"))
        info_pessoas.append(dado_pessoa)

    for imprimindo_dados in info_pessoas:
        print(imprimindo_dados)

    pergunta = input(f"Gostaria de continuar? [S/N]\n").upper()
print("Finalizando progama...")
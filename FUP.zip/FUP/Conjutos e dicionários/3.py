pergunta = "S"
while pergunta == "S":
    alunos_informações = []

    addi = "S"
    while addi == "S":
        dict = {}
        dict["Nome"] = input("Digite o nome do aluno: ")
        dict["N_matrícula"] = int(input("Digite o número da matrícula: "))
        dict["Curso"] = input("Digite o curso do aluno: ")
        alunos_informações.append(dict)

        addi = input("Quer add mais algum aluno? [S/N] ").upper()
    
    for info in alunos_informações:
        print(info)
        
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando programa")

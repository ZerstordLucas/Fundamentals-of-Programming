pergunta = "S"
while pergunta == "S":
    info_alunos = {}

    for i in range(5):
        matricula = int(input(f"Digite a matrícula do aluno: "))
        nome = input("Digite o nome do aluno: ")
        nota1 = float(input(f"Digite a primeira nota de {nome}: "))
        nota2 = float(input(f"Digite a segunda nota de {nome}: "))
        nota3 = float(input(f"Digite a terceira nota de {nome}: "))
        print("/"*35)
        media = (nota1 + nota2 + nota3)/3
        info_alunos[nome] = {"matricula": matricula, "nota1":nota1, "nota2": nota2, "nota3": nota3, "media": media}

    maior_nota_1 = 0
    nome_aluno = ""
    for nome, dados in info_alunos.items():
        if dados["nota1"] > maior_nota_1:
            maior_media = dados["nota1"]
            nome_aluno = nome
    print(f"A maior nota da primeira prova foi de {nome_aluno}, com nota de {maior_nota_1}.")

    maior_media = 0
    nome_do_aluno = ""
    for nome, dados in info_alunos.items():
        if dados["media"] > maior_media:
            maior_media = dados["media"]
            nome_do_aluno = nome
    print(f"A maior média foi de {nome_do_aluno}, com nota de {maior_media}.")

    menor_media = 10
    nome__aluno = ""
    for nome, dados in info_alunos.items():
        if dados["media"] < menor_media:
            menor_media = dados["media"]
            nome__aluno = nome
    print(f"A menor média foi de {nome__aluno}, com nota de {menor_media}.")

    pergunta = input("Quer continuar? [S/N] ").upper()
print("Finalizando programa...")
pergunta = "S"
while pergunta == "S":
    dados_usuário = {}

    dados_usuário["nome"] = input("Digite seu nome: ")
    dados_usuário["endereco"] = input("Digite seu endereço: ")
    dados_usuário["data_N"] = input("Digite a data de nascimento: ")
    dados_usuário["cidade"] = input("Digite o nome da sua cidade: ")
    dados_usuário["cep"]= input("Digite seu CEP: ")
    dados_usuário["email"] = input("Digite seu email: ")

    if dados_usuário["data_N"].isnumeric()== False and len(dados_usuário["data_N"].split("/")) != 3 and len(dados_usuário["data_N"]) !=10:
        print("Data inválida, preencha os dados corretamente.")
        continue
    elif  dados_usuário["cep"].isnumeric()==False and len(dados_usuário["cep"].split(".")) != 1 and len(dados_usuário["cep"].split("-")) != 1:
        print("CEP inválido, preencha os dados corretamente.")
        continue
    elif ("@" not in dados_usuário["email"]) and (".com" not in dados_usuário["email"]):
        print("Email inválido, preencha os dados corretamente.")
        continue
    else:
        print(dados_usuário)
        
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando o programa...")


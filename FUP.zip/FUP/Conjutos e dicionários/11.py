def soma(dicionario):
    resultado = {}
    resultado["real"] = dicionario["z"] + dicionario["w"]
    resultado["imaginario"] = dicionario["zi"] + dicionario["wi"]
    return resultado

def subtração(dicionario):
    resultado_menos = {}
    resultado_menos["real"] = dicionario["z"] - dicionario["w"]
    resultado_menos["imaginario"] = dicionario["zi"] - dicionario["wi"]
    return resultado_menos

def produto(dicionario):
    resultado_multi = {}
    resultado_multi["real"] = dicionario["z"] * dicionario["w"]
    resultado_multi["imaginario"] = dicionario["zi"] * dicionario["wi"]
    return resultado_multi

def modulo(dicionario):
    resultado_mod = {}
    resultado_mod["real"] = ((dicionario["z"]**2) + (dicionario["w"]**2)) **0.5
    resultado_mod["imaginario"] = (dicionario["zi"]**2) + (dicionario["wi"]**2) **0.5
    return resultado_mod

pergunta = "S"
while pergunta == "S":
    armazem = {}
    armazem["z"] = int(input("Digite um número para Z: "))
    armazem["zi"] = int(input("Digite um número para Z imaginário: "))
    armazem["w"] = int(input("Digite um número para W: "))
    armazem["wi"] = int(input("Digite um número para W imaginário: "))

    print(soma(armazem))
    print(subtração(armazem))
    print(produto(armazem))
    print(modulo(armazem))

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando progama...")


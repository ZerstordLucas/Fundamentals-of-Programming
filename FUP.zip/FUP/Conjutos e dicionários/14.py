def buscador(info, valor):
    menores = {}
    for marca, preço in info.items():
        if preço["preco"] < valor:
            menores[marca] = {"preco": preço}
    return menores

pergunta = "S"
while pergunta == "S":
    dados = {}
    for i in range(2):
        marca = input("Digite a marca do carro: ")
        ano = int(input("Digite o ano do carro: "))
        preco = float(input("Digite o valor do carro: "))
        dados[marca] = {"ano":ano, "preco": preco}

    valor_busca = float(input("Digite um valor para realizar a busca: "))
    print(buscador(dados, valor_busca ))

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando o programa...")




def apresentar(d):
    for apresentar in d.items():
        print(apresentar)

def procurar(info_livro, chave):
    resultado = {}
    for n, dados in info_livro.items():
        if chave.lower() in n.lower():
            resultado[n] = {"dados":dados} 

    return resultado

pergunta = "S"
while pergunta == "S":
    dados = {}
    for preencher in range(2):
        titulo = input("Digite o título do livro: ")
        autor = input("Digite o autor do livro: ")
        ano = int(input("Digite o ano de publicação do livro: "))
        dados[titulo] = {"autor": autor, "ano": ano}

    print("Os livros diponíveis:")
    apresentar(dados)
    print("/"*40)
    buscador = input("Digite o título do livro que quer encontrar:  ")
    busca_final = procurar(dados,buscador)
    print(f"Os livros econtrado:")
    apresentar(busca_final)

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando o programa...")


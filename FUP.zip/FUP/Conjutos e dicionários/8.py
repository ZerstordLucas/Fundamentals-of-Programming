import math
def calculos(x,y):
    x1 = round((x * math.cos(y)), 2)
    y1 = round((x * math.sin(y)), 2)
    return x1, y1
pergunta = "S"
while pergunta == "S":

    coordenada_r = float(input("Digite a coordenada polar, em raio(r): "))
    coordenada_a = float(input("Digite a coordenada polar, em ângulo(a): "))

    cartesianoX, cartesianoY = calculos(coordenada_r,coordenada_a)

    print(f"As coordenadas polar digitadas pelo usuário foram aproximadamente: ({coordenada_r}, {coordenada_a}).")
    print(f"As coordenadas cartesianas cálculadas foram aproximadamente: ({cartesianoX}, {cartesianoY}).")

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando programa...")
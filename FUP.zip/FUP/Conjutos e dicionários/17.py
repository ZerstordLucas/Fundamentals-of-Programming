pergunta = "S"
while pergunta == "S":

    eletrodomesticos = []
    for i in range(1, 6):
        print(f"Digite informações do eletrodomestico {i}:")
        nome = input("Nome: ")[:15]
        pot = float(input("Potencia (em kW): "))
        tempo = float(input("Tempo em horas por dia: "))
        eletrodomesticos.append({'nome': nome, 'pot': pot, 'tempo': tempo})

    while True:
        t = int(input("Aperte 0 para terminar: "))
        if t == 0:
            break
        consumo_total = 0
        for app in eletrodomesticos:
            consumo = app['pot'] * app['tempo'] * t
            app['consumo'] = consumo
            consumo_total += consumo
        print("Consumo total na casa (em kWh):", consumo_total)
        print("Consumo relativo:")
        for app in eletrodomesticos:
            calculo = app['consumo'] / consumo_total * 100
            print(f"{app['nome']}: {calculo:.2f}%")
    
    pergunta = input("Gostaria de continua? [S/N] ").upper()
print("Finalizando programa.")


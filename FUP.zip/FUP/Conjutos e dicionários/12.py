def classificar(lista):
    aprovados = {}
    reprovados = {}

    for analise_aluno, media in lista.items():
        if media["media"] >=5:
            aprovados[analise_aluno] = {"media": media["media"]}
        else:
            reprovados[analise_aluno] = {"media": media["media"]}
    return aprovados, reprovados

pergunta = "S"
while pergunta == "S":
    dados_alunos = {}
    for qntd in range(2):
        nome= input(f"Digite o nome do {qntd+1}° aluno: ")
        matricula = int(input(f"Digite o número da matrícula do {qntd+1}° aluno: "))
        media = float(input(f"Digite a média final do {qntd+1}° aluno: "))
        dados_alunos[nome] =  { "matricula": matricula, "media": media}
        
    x, y = classificar(dados_alunos)
    print(f"Aprovados:\n {x}")
    print("/"*30)
    print(f"Reprovados: \n{y}")
    pergunta = input(f"Gostaria de continuar? [S/N] \n").upper()
print("Finalizando programa...")


def saber_menor_consumo(lista):
    menor = min(lista)
    return menor 

def calcular_consumo(lista):
    for modelo, km in lista.items():
        print(f"O {modelo} percorre {km*50} kilometros com 50 litros.")

def calcular_consumo_percorrido(lista):
    for modelo, km in lista.items():
        print(f"O {modelo} consome {round(1000/km,2)} litros percorrendo 1000 Km.")


pergunta = "S"
while pergunta == "S":
    modelos_e_consumo = {}

    for criador in range(5):
        modelo_do_carro = input(f"Digite o modelo do carro {criador+1}: ")
        modelos_e_consumo[modelo_do_carro] = float(input(f"Digite o consumo por Km/litro do {modelo_do_carro}: "))
    
    print("/"*40)
    print(f"O carro que tem menor consumo é o {saber_menor_consumo(modelos_e_consumo)}")
    print("/"*40)
    calcular_consumo(modelos_e_consumo)
    print("/"*40)
    calcular_consumo_percorrido(modelos_e_consumo)
    
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando o programa...")

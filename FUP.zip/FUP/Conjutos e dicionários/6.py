def soma (d1, d2):
    dic = {}
    dic["x"] = d1["x1"] + d2["x2"]
    dic["y"] = d1["y1"] + d2["y2"]
    dic["z"] = d1["z1"] + d2["y2"]
    return dic

pergunta = "S"
while pergunta == "S":

    dici1 = {}
    x1 = float(input("Digite um número para x: "))
    y1 = float(input("Digite um número para y: "))
    z1 = float(input("Digite um número para z: "))
    dici1 = { "x1":x1, "y1":y1, "z1":z1}

    dici2 = {}
    x2 = float(input("Digite um número para x: "))
    y2 = float(input("Digite um número para y: "))
    z2 = float(input("Digite um número para z: "))
    dici2 = {"x2": x2, "y2":y2, "z2":z2}

    result_dic = soma(dici1, dici2)
    print(f"A soma dos vetores é:")
    print(f"X = {result_dic["x"]}, Y = {result_dic["y"]}, Z = {result_dic["z"]}")

    pergunta = input("Quer continuar? [S/N] ").upper()
print("Finalizando programa....")
pergunta = "S"
while pergunta == "S":
    informações = {}
    for i in range(2):
        nome = input(f"Digite o nome do cadastro {i+1}: ")
        endereco = input(f"Digite o endereço do cadastro {i+1}: ")
        salario = float(input(f"Digite o salário do cadastro {i+1}: "))
        identidade = int(input(f"Digite a identidade do cadastro {i+1}: "))
        cpf = int(input(f"Digite o CPF do cadastro {i+1}: "))
        estado_civil = input(f"Digite o estado civil do cadastro {i+1}: ")
        telefone = int(input(f"Digite o telefone do cadastro {i+1}: "))
        idade = int(input(f"Digite a idade do cadastro {i+1}: "))
        sexo = input(f"Digite o sexo do cadastro {i+1}: [F/M] ").upper()

        informações[nome] = {"endereco":endereco, "salario": salario, "identidade": identidade, 
                             "cpf": cpf, "estado_civil":estado_civil, "telefone": telefone,
                             "idade":idade, "sexo": sexo
                             }

    maior = ""
    id = 0
    for n, da in informações.items():
        if da["idade"] > id:
            id = da["idade"]
            maior = n
    
    p_masculino = []
    for nom, dad in informações.items():
        if "M" in dad["sexo"]:
            p_masculino.append(nom)

    p_salario = []
    for nomee, dado in informações.items():
        if dado["salario"] > 1000:
            p_salario.append(nomee)

    print(f"A pesoa de maior idade é {maior}")
    print(f"As pessoas de sexo masculino são:\n {p_masculino}")
    print(f"As pessoas que tem salário maior que R$1000,00 são: \n {p_salario}")


    busca_iden = int(input("Digite a identidade para pesquisar o cadastro: "))

    for info, identidade_busca in informações.items():
        if identidade_busca["identidade"] == busca_iden:
            print("Resultado encontrado: ")
            print(info)
            print(identidade_busca)
        
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando programa...")




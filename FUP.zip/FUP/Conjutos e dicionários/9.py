pergunta = "S"
while pergunta == "S":
    dados = {}
    dados["nome"] = input("Digite o nome do funcionário: ")
    dados["idade"] = int(input("Digite a idade do funcionário: "))
    dados["sexo"] = input("Digite o sexo do funcionário (M/F): ").upper()
    dados["cpf"] = int(input("Digite o CPF do funcionário: "))
    dados["nascimento"] = input("Digite a data de nascimento do funcionário no formado DD/MM/AAAA: ")
    dados["setor"] = int(input("Digite o código do setor do funcionário(0-99): "))
    dados["cargo"] = input("Digite o cargo do funcionário: ")
    dados["salario"] = float(input("Digite o sálario do funcionário: "))


    pergunta = input("Gostaria de continuar? [S/N]  ").upper()
print("Finalizando progama...")
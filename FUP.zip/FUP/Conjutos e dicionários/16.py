pergunta = "S"
while pergunta == "S":
    agenda = []
    for i in range(1, 6):
        print(f"Informe os dados do compromisso {i}:")
        cdesc = input("Compromisso: ")
        print("Data:")
        d = int(input("Dia: "))
        m = int(input("Mes: "))
        aa = int(input("Ano: "))
        agenda.append({'compromisso': cdesc, 'data': {'dia': d, 'mes': m, 'ano': aa}})

    while True:
        mes_info = int(input("Informe um mes M (ou '0' para terminar): "))
        if mes_info == 0:
            break
        ano_info = int(input("Informe um ano A: "))
        print("Compromissos para o mes", mes_info, "do ano", ano_info, ":")
        cpmes = [c for c in agenda if c['data']['mes'] == mes_info and c['data']['ano'] == ano_info]
        cpmes.sort(key=lambda x: x['data']['dia'])
        for c in cpmes:
            print(c)
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando progama...")
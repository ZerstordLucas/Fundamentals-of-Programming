pergunta = "S"
while pergunta == "S":
    qntd_aluno = int(input("Qual o tamanho da turma?  "))

    info_alunos = {}
    for preencher in range(qntd_aluno):
        nome = input("Digite o nome do aluno: ")
        matricula = int(input(f"Digite  a matrícula de {nome}: "))
        codigo = input(f"Digite o código da diciplina de {nome}: ")
        nota1 = float(input(f"Digite a primeira nota de {nome}: "))
        nota2 = float(input(f"Digite a segunda nota de {nome}: "))
        calc_media = ((nota1*1) + (nota2*2))/2

        info_alunos[matricula] = {"nome": nome, "código_diciplina": codigo, 
                                 "nota_1":nota1, "nota_2":nota2, "média": calc_media }
        
    for matricula, dados in info_alunos.items():
        print(f"O aluno(a) {dados["nome"]} teve sua média final ponderada de {dados["média"]}.")

    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Finalizando programa...")

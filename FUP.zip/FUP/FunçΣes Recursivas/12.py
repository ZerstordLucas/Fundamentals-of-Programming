def h(x, y):
    if y == 1:
        return(x+1)
    elif x ==1:
        return(y+1)
    elif x>1 and y>1 :
        return(h(x , y-1) + h(x -1, y))

pergunta = "S"
while pergunta == "S":
    m = int(input("Digite o primeiro número: "))
    n = int(input("Digite o segundo número: "))
    print(h(m,n))
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim!")

def decresce(x):
    contador = 0
    if x == contador:
        print(0)
    else:
        print(x)
        decresce(x-1)
pergunta = "S"
while pergunta == "S":
    n = int(input("Digite um valor para N: "))
    if n >0:
        print(decresce(n))
    pergunta = input("Gostaria de continuar? [S/N ]").upper()
print("FIm!")
def cubin(x):
    if x == 1:
        return (1)
    else:
        return(x**2 +(cubin(x-1)))
pergunta = "S"
while pergunta == "S":
    numero = input("Digite um número:\n")
    if numero.isnumeric():
        numero = int(numero)
        print(f"A soma dos cubos é {cubin(numero)}")
    else:
        print("Digite um número, não uma letra!")
        continue
    pergunta = input("Gostaria de continuar? [S/N]\n").upper()
print("Fim do progama!")
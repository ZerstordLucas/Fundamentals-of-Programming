def a(x, y):
    if x == 0:
        return y+1
    elif x >0 and y == 0:
        return a(x-1, 1)
    elif x > 0 and y>0:
        return a(x-1, a(x, y-1))
    
pergunta = "S"
while pergunta == "S":
    m = int(input("Digite o primeiro número: "))
    n = int(input("Digite o segundo número: "))
    print(a(m,n))
    pergunta = input("Gostaria de continuar? [S/N] ").upper()
print("Fim!")
def sequencia(x):
    if x == 1:
        return 1
    if x == 2:
        return 2
    return (2*sequencia(x-1) + 3* sequencia(x-2))

pergunta = "S"
while pergunta == "S":
    num = int(input("Digite um número: "))
    print(sequencia(num))
    pergunta = input("Gostaria de continuar? [S/N ]").upper()
print("Fim!")
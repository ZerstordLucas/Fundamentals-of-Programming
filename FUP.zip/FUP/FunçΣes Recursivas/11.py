def mmc(x,y):
    if y == 0:
        return x
    return(mmc(y, x%y))
pergunta = "S"
while pergunta == "S":
    num1 = int(input("Digite o primeiro número: "))
    num2 = int(input("Digite o segundo número: "))
    print(mmc(num1, num2))
    pergunta = input("Gostaria de continuar? [S/N]").upper()
print("Fim!")
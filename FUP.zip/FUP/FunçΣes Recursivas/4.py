
def potencia(x, y):
    if y == 0:
        return(1)
    return(x*(potencia(x, y-1)))

pergunta = "S"
while pergunta == "S":
    n = int(input("Digite um valor para base: "))
    k = int(input("Digite um valor para o expoente: "))
    if k >= 0:
        print(f"O valor é {potencia(n,k)}")
    else:
        print("Digite um valor inteiro positivo.")
        continue
    pergunta = input("Gostaria de continurar? [S/N] ").upper()
print("Fim do progama!")
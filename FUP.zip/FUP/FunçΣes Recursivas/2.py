def fatorial(x):
    if x == 0:
        return 1
    else:
        return(x*fatorial(x-1))
pergunta = "S"
while pergunta == "S":
    numero = input("Digite um número:\n")
    if numero.isdigit():
        numero = int(numero)
        if numero < 1559:
            print(f"O resultado é {fatorial(numero)}")
        else:
            print("O número ultrapassa de 4300 carcteres, não há como representar!")
            continue
    else:
        print("Digite somente números!")
        continue
    pergunta = input("Gostaria de continuar? [S/N]").upper()
print("Fim do progama!")
def soma(x, y, z):
    if x> y:
        return 0
    return (x + soma(x+z, y, z))

    
pergunta = "S"
while pergunta == "S":
    i = input("Digite um valor para i:  ")
    if i.isnumeric():
        i = int(i)
        j = input("Digite um valor para j:  ")
        
        if j.isnumeric():
            j = int(j)
            
            if j > i:
                k = input("Digite um valor para K: ")
                
                if k.isnumeric():
                    k = int(k)
                    print(f"O somatório é igual a {soma(i,j,k)}")
                else:
                    print("Valor inválido")
                    continue
            else:
                print("O somatório é igual a 0, pois i é maior que k!")
                continue

        else:
            print("O valor é inválido!")
            continue

    else:
        print("O valor é inválido!")
        continue
    pergunta = input("Gostaria de continuar? [S/N]\n").upper()
print("Encerrando progama...")

# Ha um erro quando i > j, print errado!
# confedir os inteiros positivos, para não dar error

def soma (x):
    if x ==1:
        return 1
    return(x+soma(x-1))


pergunta = "S"
while pergunta == "S":
    x = int(input("Digite um número: "))
    if x >= 0:
        print(f"O somatório de {x} é igual a {soma(x)}")
    else:
        print("Digite um valor inteiro positivo")
        continue

    pergunta = input("Deseja continuar? [S/N] ").upper()
print("Fim do Progama! Adios!")
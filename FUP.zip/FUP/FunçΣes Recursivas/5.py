def cresce(x, contador = 0):
    if contador == x+1:
        return(contador)
    print(contador)
    cresce(x, contador+1)
pergunta = "S"
while pergunta == "S":
    n = int(input("Digite um valor para N: "))
    if n >0:
        print(cresce(n))
    pergunta = input("Gostaria de continuar? [S/N ]").upper()
print("FIm!")
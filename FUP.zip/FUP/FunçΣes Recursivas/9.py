def fatorial(x):
    if x == 1:
        return 1
    return x * fatorial(x-1)

def superfatorial(s):
    if s == 1:
        return s
    return fatorial(s) * superfatorial(s -1)

pergunta = "S"
while pergunta == "S":
    numero = input("Digite um número:\n")
    if numero.isnumeric():
        numero = int(numero)
        print(superfatorial(numero))
    else:
        print("Digite somente números.")
        continue
    pergunta = input("Gostaria de continuar? [S/N]\n").upper()
print("Fim do progama!")
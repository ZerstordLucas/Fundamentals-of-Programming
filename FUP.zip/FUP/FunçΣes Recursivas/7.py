def crescente_par(x, contador =0):
    if contador == x+1:
        return(contador)
    elif contador %2 == 0:
        print(contador)
    crescente_par(x, contador+1)
    

pergunta = "S"
while pergunta == "S":
    numero = input("Digite um número:\n")
    if numero.isnumeric():
        numero = int(numero)
        print(crescente_par(numero))
    else:
        print("Digite somente números.")
        continue
    pergunta = input("Gostaria de continuar? [S/N]\n").upper()
print("Fim do progama!")